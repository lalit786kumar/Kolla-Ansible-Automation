# 🚀 OpenStack VM Deployment with Terraform

## Prerequisites

- Terraform 1.x installed
- OpenStack project with:
  - Network ID (private network)
  - Available image and flavor
  - Floating IP pool (e.g. "public")
- SSH public key present at `~/.ssh/id_rsa.pub`

## Setup

1. Clone this repo or copy the directory:

   ```bash
   git clone <repo> terraform-openstack/
   cd terraform-openstack/
